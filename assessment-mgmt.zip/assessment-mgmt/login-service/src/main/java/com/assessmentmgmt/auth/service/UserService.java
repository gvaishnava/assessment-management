package com.assessmentmgmt.auth.service;

import com.assessmentmgmt.auth.domain.User;

public interface UserService {

	void create(User user);

}
