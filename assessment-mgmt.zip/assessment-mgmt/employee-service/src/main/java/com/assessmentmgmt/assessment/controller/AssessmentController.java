package com.assessmentmgmt.assessment.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.assessmentmgmt.assessment.domain.Assessment;
import com.assessmentmgmt.assessment.domain.User;
import com.assessmentmgmt.assessment.service.AssessmentServiceImpl;

import javax.validation.Valid;
import java.security.Principal;

import org.springframework.ui.Model;

@RestController
public class AssessmentController {

	@Autowired
	private AssessmentServiceImpl assessmentService;

	@PreAuthorize("#oauth2.hasScope('server') or #name.equals('demo')")
	@RequestMapping(path = "/", method = RequestMethod.GET)
	public String getAssessments(Model model) {
		Iterable<Assessment> assessments = assessmentService.findAll();
		model.addAttribute("assessment-list", assessments);
		return "assessment-list";
	}

//	@RequestMapping(path = "/", method = RequestMethod.GET)
//	public Assessment getAssessment(Principal principal) {
//		return assessmentService.findByName(principal.getName());
//	}

//	@RequestMapping(path = "/", method = RequestMethod.PUT)
//	public void saveAssessment(Principal principal, @Valid @RequestBody Assessment assessment) {
//		assessmentService.saveChanges(principal.getName(), assessment);
//	}

	@RequestMapping(path = "/", method = RequestMethod.POST)
	public String createNewAssessment(Model model, Principal principal, @Valid @RequestBody Assessment assessment) {
		assessment.setUsername(principal.getName());
		model.addAttribute("assessment", assessmentService.create(assessment.getName(), assessment));
		return "assessment";
	}

}
