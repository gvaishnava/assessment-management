package com.assessmentmgmt.assessment.service;

import java.math.BigDecimal;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import com.assessmentmgmt.assessment.domain.Assessment;
import com.assessmentmgmt.assessment.domain.AssessmentType;
import com.assessmentmgmt.assessment.domain.User;
import com.assessmentmgmt.assessment.repository.AssessmentRepository;

@Service
public class AssessmentServiceImpl implements AssessmentService{
	private final Logger log = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private AssessmentRepository repository;
	
		
	@Override
	public Assessment create(String name, Assessment assessment) {

		Assessment existing = repository.findByName(name);
		Assert.isNull(existing, "assessment already exists: " + name);
       repository.save(assessment);

		log.info("new accessment has been created: " + assessment.getName());

		return assessment;
	}


	public Iterable<Assessment> findAll() {
		return repository.findAll();
	}
}
