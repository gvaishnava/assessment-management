package com.assessmentmgmt.assessment.service;

import com.assessmentmgmt.assessment.domain.Assessment;
import com.assessmentmgmt.assessment.domain.User;

public interface AssessmentService {
	


	/**
	 * Checks if accessment with the same name already exists
	 * Invokes Auth Service user creation
	 * Creates new assessment with default parameters
	 *
	 * @param user
	 * @return created assessment
	 */
	Assessment create(String name, Assessment assessment);



}
