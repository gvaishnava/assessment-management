package com.assessmentmgmt.assessment.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.assessmentmgmt.assessment.domain.Assessment;

@Repository
public interface AssessmentRepository extends CrudRepository<Assessment, String> {

	Assessment findByName(String name);

}
