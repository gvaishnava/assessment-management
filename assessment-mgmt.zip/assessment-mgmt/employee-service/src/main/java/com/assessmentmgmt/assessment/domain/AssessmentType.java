package com.assessmentmgmt.assessment.domain;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "assessment")
@JsonIgnoreProperties(ignoreUnknown = true)
public class AssessmentType {
	
	String type;
	
	

}
