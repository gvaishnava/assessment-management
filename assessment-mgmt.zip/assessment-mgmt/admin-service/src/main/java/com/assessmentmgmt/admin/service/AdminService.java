package com.assessmentmgmt.admin.service;

public interface AdminService {

}
