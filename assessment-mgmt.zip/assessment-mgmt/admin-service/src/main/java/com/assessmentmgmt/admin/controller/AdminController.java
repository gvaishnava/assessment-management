package com.assessmentmgmt.admin.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.assessmentmgmt.admin.client.AssessmentServiceClient;
import com.assessmentmgmt.admin.repository.Assessment;



public class AdminController {
	
	@Autowired
	private AssessmentServiceClient assessmentService;

	@PreAuthorize("#oauth2.hasScope('admin') or #name.equals('demo')")
	@RequestMapping(path = "/", method = RequestMethod.GET)
	public String getAssessments() {
		return assessmentService.getAssessments();
	}

}
