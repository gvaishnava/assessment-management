package com.assessmentmgmt.admin.client;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.assessmentmgmt.admin.domain.User;
import com.assessmentmgmt.admin.repository.Assessment;


@FeignClient(name = "assessment-service")
public interface AssessmentServiceClient {

	@RequestMapping(method = RequestMethod.GET, value = "/assessments/", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
	String getAssessments();
}
