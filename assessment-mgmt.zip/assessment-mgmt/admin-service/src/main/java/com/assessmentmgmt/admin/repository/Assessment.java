package com.assessmentmgmt.admin.repository;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "employee")
@JsonIgnoreProperties(ignoreUnknown = true)
public class Assessment {
	
	@Id
	private String name;
	
	private String username;
	
	AssessmentType assessmentType;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public AssessmentType getAssessmentType() {
		return assessmentType;
	}

	public void setAssessmentType(AssessmentType assessmentType) {
		this.assessmentType = assessmentType;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}


	

}
