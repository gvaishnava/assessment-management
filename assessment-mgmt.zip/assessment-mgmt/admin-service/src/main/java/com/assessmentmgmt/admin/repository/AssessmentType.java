package com.assessmentmgmt.admin.repository;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "assessment")
@JsonIgnoreProperties(ignoreUnknown = true)
public class AssessmentType {
	
	String type;
	
	

}
