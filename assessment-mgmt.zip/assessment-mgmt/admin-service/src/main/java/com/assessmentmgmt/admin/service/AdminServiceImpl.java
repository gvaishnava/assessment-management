package com.assessmentmgmt.admin.service;

public class AdminServiceImpl {

}
