package com.assessmentmgmt.admin.repository;

public interface AdminRepository {

}
